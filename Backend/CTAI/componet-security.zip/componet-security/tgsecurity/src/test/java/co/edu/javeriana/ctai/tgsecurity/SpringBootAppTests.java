package co.edu.javeriana.ctai.tgsecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAppTests {

    @Test
    void contextLoads() {
    }

}
