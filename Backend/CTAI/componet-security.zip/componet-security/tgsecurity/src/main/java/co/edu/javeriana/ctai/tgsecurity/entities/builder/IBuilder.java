package co.edu.javeriana.ctai.tgsecurity.entities.builder;

public interface IBuilder<T> {
    T build();
}
