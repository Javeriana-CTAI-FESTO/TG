package co.edu.javeriana.ctai.tgsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootApp {

    public static void main(String[] args) {
        // contenedor de beans
        SpringApplication.run(SpringBootApp.class, args);

    }

}
