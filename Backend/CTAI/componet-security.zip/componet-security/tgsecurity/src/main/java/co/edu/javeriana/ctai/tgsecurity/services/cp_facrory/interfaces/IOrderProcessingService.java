package co.edu.javeriana.ctai.tgsecurity.services.cp_facrory.interfaces;

public interface IOrderProcessingService {
}
