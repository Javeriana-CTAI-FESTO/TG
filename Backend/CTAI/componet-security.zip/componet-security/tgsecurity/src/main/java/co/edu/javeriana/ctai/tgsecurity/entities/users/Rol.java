package co.edu.javeriana.ctai.tgsecurity.entities.users;

public enum Rol {
    ADMIN,
    STUDENT,
    TEACHER,
    SHOPPER
}